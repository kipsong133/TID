import UIKit

// MARK: - 프로토콜을 이용한 의존성 주입

// ID를 생성한다.
protocol IDProvider {
    func getGameID() -> UUID
}

struct UserID: IDProvider {
    let userID: UUID
    func getGameID() -> UUID { userID }
}

// 시간을 생성한다.
protocol TimeProvider {
    func now() -> Date
}

struct GameStartTime: TimeProvider {
    let starteTime: Date
    func now() -> Date { starteTime }
}

// 게임을 생성한다.
struct Game {
    private let startTime: Date
    private let userID: UUID
    
    init(userID: UUID, startTime: Date) {
        self.userID = userID
        self.startTime = startTime
    }
}

// 게임을 담당하는 객체를 생성한다.
class GameService01 {
    
    private let idProvider: IDProvider // ID
    private let timeProvider: TimeProvider // Time
    
    init(idProvider: IDProvider, timeProvider: TimeProvider) {
        self.idProvider = idProvider
        self.timeProvider = timeProvider
    }
    
    // 게임을 생성한다.
    func createGame() -> Game {
        
        let id = idProvider.getGameID() // ID 생성
        let date = timeProvider.now() // 시간 생성
        let game = Game(userID: id, startTime: date) // 게임 생성
        return game
    }
}

// 초기화
let gameService01 = GameService01(
    idProvider: UserID(userID: UUID()),
    timeProvider: GameStartTime(starteTime: Date()))
gameService01.createGame()


// MARK: - 함수를 이용한 의존성 주입
class GameService02 {

    private let getID: () -> UUID
    private let getTime: () -> Date

    init(getID: @escaping () -> UUID, getTime: @escaping () -> Date) {
        self.getID = getID
        self.getTime = getTime
    }

    func createGame() -> Game {
        
        let id = getID()
        let date = getTime()
        let game = Game(userID: id, startTime: date)

        // Do something with the game
        return game
    }
}

let gameService02 = GameService02(
    getID: { UUID() }, // getID: UUID.init
    getTime: { Date() }) // getTime: Date.init
gameService02.createGame()
